

const periode = document.querySelector('#tanggal p');
const tanggal = new Date().getDate();
periode.innerHTML = 'Periode' + tanggal;
console.log(tanggal);


const btnNode = document.querySelector('.check .btn-warna')
const btn = document.querySelector('#checkouty')
// btn.innerHTML = 'hallo';
btn.parentElement.removeChild(btn);